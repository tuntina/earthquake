Showing the Population of Turkey on the Map with Python (Geopandas)

Youtube

  > Part1: https://www.youtube.com/watch?v=s3RJ8oeTvXQ&t=37s,
  > Part2: https://www.youtube.com/watch?v=4ox02WgiTWk



#### <span style="color: blue">geopandas installation : </span>https://towardsdatascience.com/geopandas-installation-the-easy-way-for-windows-31a666b3610f
#### <span style="color: blue">Turkey map data : </span>http://www.diva-gis.org/gdata
#### <span style="color: blue">Turkey Population data : </span>https://data.tuik.gov.tr/Bulten/Index?p=The-Results-of-Address-Based-Population-Registration-System-2020-37210&dil=2

![alt text](https://github.com/osmanballi/Turkey_population_with_geopandas/blob/main/Turkeyplot.PNG)
